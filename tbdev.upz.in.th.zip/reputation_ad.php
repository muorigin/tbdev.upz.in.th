<?php
/*
+------------------------------------------------
|   TBDev.net BitTorrent Tracker PHP
|   =============================================
|   by CoLdFuSiOn
|   (c) 2003 - 2011 TBDev.Net
|   http://www.tbdev.net
|   =============================================
|   svn: http://sourceforge.net/projects/tbdevnet/
|   Licence Info: GPL
+------------------------------------------------
|   $Date$
|   $Revision$
|   $Author$
|   $URL$
+------------------------------------------------
*/
require_once "include/bittorrent.php";
require_once "include/user_functions.php";

dbconn( false );

loggedinorreturn();

	$lang = load_language('global');

	if ( get_user_class() < UC_ADMINISTRATOR )
		header( "Location: {$TBDEV['baseurl']}/index.php" );

	$input = array_merge($_GET, $_POST);
	$input['mode'] = isset( $input['mode'] ) ? $input['mode'] : '';
	$now_date     = "";
	$reputationid = 0;
	$time_offset = 0;

		
		$a = explode(",", gmdate("Y,n,j,G,i,s", TIME_NOW + $time_offset));
		$now_date = array( 'year' => $a[0], 'mon' => $a[1], 'mday' => $a[2],
								 'hours' => $a[3], 'minutes' => $a[4], 'seconds' => $a[5] );


		switch( $input['mode'] )
		{
			case 'modify':
				show_level();
				break;
			case 'add':
				show_form('new');
				break;
			case 'doadd':
				do_update('new');
				break;
			case 'edit':
				show_form('edit');
				break;
			case 'doedit':
				do_update('edit');
				break;
			case 'doupdate':
				do_update();
				break;
			case 'dodelete':
				do_delete();
				break;
			case 'list':
				view_list();
				break;
			case 'dolist':
				do_list();
				break;
			case 'editrep':
				show_form_rep('edit');
				break;
			case 'doeditrep':
				do_edit_rep();
				break;
			case 'dodelrep':
				do_delete_rep();
				break;

			default:
				show_level();
				break;
		}
	


function show_level()
	{
		$title = "User Reputation Manager - Overview";

    	$html = "<p>On this page you can modify the minimum amount required for each reputation level. Make sure you press Update Minimum Levels to save your changes. You cannot set the same minimum amount to more than one level.<br />From here you can also choose to edit or remove any single level. Click the Edit link to modify the Level description (see Editing a Reputation Level) or click Remove to delete a level. If you remove a level or modify the minimum reputation needed to be at a level, all users will be updated to reflect their new level if necessary.</p><br />";

		$query = mysql_query( 'SELECT * FROM reputationlevel ORDER BY minimumreputation ASC' );
		

		if( ! mysql_num_rows( $query ) )
		{
			do_update( 'new' );
			return;
		}
        $html .= "
                     <div class='cblock'>
                         <div class='cblock-header'>User Reputation Manager <span class='btn' style='float:right;'><a href='reputation_ad.php?mode=list'>View comments</a></span></div>
                         <div class='cblock-content'>";
		$html .= "           <form action='reputation_ad.php' name='show_rep_form' method='post'>
				                  <input name='mode' value='doupdate' type='hidden' />";
		$html .= "                      <table cellpadding='3px'>
                                              <tr>
		                                         <td style='font-weight: bold; color: #ffffff; background-color: #0055A4; padding: 5px; width:5%;'>ID</td>
		                                         <td style='font-weight: bold; color: #ffffff; background-color: #0055A4; padding: 5px; width:60%;'>Reputation Level</td>
		                                         <td style='font-weight: bold; color: #ffffff; background-color: #0055A4; padding: 5px; width:20%;'>Minimum Reputation Level</td>
		                                         <td style='font-weight: bold; color: #ffffff; background-color: #0055A4; padding: 5px; width:15%;'>Controls</td>
                                              </tr>";



		while( $res = mysql_fetch_assoc( $query ) )
		{
			$html .= "                        <tr>
				                                 <td>#".$res['reputationlevelid']."</td>
					                             <td>User <b>".htmlsafechars( $res['level'] )."</b></td>
					                             <td class='center'><input type='text' name='reputation[".$res['reputationlevelid']."]' value='".$res['minimumreputation']."' size='12' /></td>
					                             <td class='center'><span class='btn'><a href='reputation_ad.php?mode=edit&amp;reputationlevelid=".$res['reputationlevelid']."'>Edit</a></span>&nbsp;<span class='btn'><a href='reputation_ad.php?mode=dodelete&amp;reputationlevelid=".$res['reputationlevelid']."'>Delete</a></span></td>
				                              </tr>\n";
		}

		$html .= "                            <tr>
                                                 <td colspan='3' class='center'>
					                                <input type='submit' value='Update' accesskey='s' class='btn' />
					                                <input type='reset' value='Reset' accesskey='r' class='btn' />
                                                 </td>
				                         	     <td class='center'><span class='btn'><a href='reputation_ad.php?mode=add'>Add New</a></span></td>
                                              </tr>";
		$html .= "                      </table>";

		$html .= "           </form>
                         </div>
                     </div>";

		html_out( $html, $title );

	}

function show_form($type='edit')
	{
		global $input;

		$html = "";

        $html .= "
                     <div class='cblock'>
                         <div class='cblock-header'>This allows you to add a new reputation level or edit an existing reputation level.</div>
                         <div class='cblock-lb'>";



		if( $type == 'edit' )
		{
			$query = mysql_query( 'SELECT * FROM reputationlevel WHERE reputationlevelid='.intval($input['reputationlevelid']) ) or sqlerr(__LINE__,__FILE__);


			if( ! $res = mysql_fetch_assoc( $query ) )
			{
				stderr( "Error:", "Please specify an ID." );
			}

			$title  = "Edit Reputation Level";
			$html .= "       <span style='font-weight:normal;'>{$res['level']} (ID:#{$res['reputationlevelid']})</span>";
			$button = "Update";
			$extra  = "      <input type='button' class='button' value='Back' accesskey='b' class='btn' onclick='javascript:history.back(1)' />";
			$mode   = 'doedit';
		}
		else
		{
			$title  = "Add New Reputation Level";
			$button = "Save";
			$mode   = 'doadd';
			$extra  = "      <input type='button' value='Back' accesskey='b' class='btn' onclick='javascript:history.back(1)' />";
		}

        $html .= "</div>";
        $html .= "             <div class='cblock-content'>";

		$css = "style='font-weight: bold;color: #ffffff;background-color: #0055A4;padding: 5px;'";
		$replevid = isset($res['reputationlevelid']) ? $res['reputationlevelid'] : '';
		$replevel = isset($res['level']) ? htmlsafechars($res['level']) : '';
		$minrep = isset($res['minimumreputation']) ? $res['minimumreputation'] : '';
		$html .= "<form action='reputation_ad.php' id='show_rep_form' method='post'>
				<input name='reputationlevelid' value='{$replevid}' type='hidden' />
				<input name='mode' value='{$mode}' type='hidden' />";

		$html .= "<h2>$title</h2><table width='500px' cellpadding='5px'><tr>
		<td width='67%' $css>&nbsp;</td>
		<td width='33%' $css>&nbsp;</td></tr>";

		$html .= "<tr><td>Level Description<div class='desctext'>This is what is displayed for the user when their reputation points are above the amount entered as the minimum.</div></td>";
		$html .= "<td><input type='text' name='level' value=\"{$replevel}\" size='35' maxlength='250' /></td></tr>";
		$html .= "<tr><td>Minimum amount of reputation points required for this level<div>This can be a positive or a negative amount. When the user's reputation points reaches this amount, the above description will be displayed.</div></td>";
		$html .= "<td><input type='text' name='minimumreputation' value=\"{$minrep}\" size='35' maxlength='10' /></td></tr>";

		$html .= "<tr><td colspan='2' align='center'><input type='submit' value='$button' accesskey='s' class='btn' /> <input type='reset' value='Reset' accesskey='r' class='btn' /> $extra</td></tr>";
		$html .= "</table>";

		$html .= "</form>";

        $html .= "</div></div>";
		
		html_out( $html, $title );
		

	}

/////////////////////////////////////
//	Update rep function
/////////////////////////////////////
function do_update($type="")
	{
		global $input;
		
		if( $type != "" )
		{
			$level = strip_tags( $input['level'] );
			$level = trim( $level );

			if( ( strlen( $input['level'] ) < 2 ) || ( $level == "" ) )
			{
				stderr( '', 'The text you entered was too short.' );
			}

			if( strlen( $input['level'] ) > 250 )
			{
				stderr( '', 'The text entry is too long.' );
			}
			
			$level = sqlesc( $level );
			$minrep = sqlesc( intval( $input['minimumreputation'] ) );
			
			$redirect = 'Saved Reputation Level <i>'.htmlsafechars( $input['level'] ).'</i> Successfully.';
		}

		// what we gonna do?
		if( $type == 'new' )
		{
			@mysql_query( "INSERT INTO reputationlevel ( minimumreputation, level ) 
							VALUES  ($minrep, $level )" );
		}
		elseif( $type == 'edit' )
		{
			$levelid = intval( $input['reputationlevelid'] );
			if( ! is_valid_id($levelid) ) stderr('', 'Not a valid try');

			// check it's a valid rep id

			$query = mysql_query( "SELECT reputationlevelid FROM reputationlevel WHERE 
									reputationlevelid={$levelid}" );

			if( ! mysql_num_rows( $query ) )
			{
				stderr( '', 'Not a valid ID.' );
			}

			@mysql_query( "UPDATE reputationlevel SET minimumreputation = $minrep, level = $level 
							WHERE reputationlevelid = $levelid" );
		}
		else
		{
			$ids = $input['reputation'];
			if( is_array($ids) && count($ids) )
			{
				foreach( $ids as $k => $v )
				{
					@mysql_query( "UPDATE reputationlevel SET minimumreputation = ".intval($v)." WHERE reputationlevelid = ".intval($k) );
				}
			}
			else
			{
				stderr( '', 'No valid ID.' );
			}

			$redirect = "Saved Reputation Level Successfully.";
		}

		rep_cache();

		redirect( 'reputation_ad.php?mode=done', $redirect );
	}


//////////////////////////////////////
//	Reputaion delete
//////////////////////////////////////
function do_delete()
	{
		global $input;
		
		if( ! isset($input['reputationlevelid']) || ! is_valid_id($input['reputationlevelid']) )
			stderr( '', 'No valid ID.' );
			
		$levelid = intval($input['reputationlevelid']);

		// check the id is valid within db

		$query = mysql_query( "SELECT reputationlevelid FROM reputationlevel WHERE reputationlevelid=$levelid" );
		
		if( ! mysql_num_rows( $query ) )
		{
			stderr( '', 'Rep ID doesn\'t exist' );
		}

		// if we here, we delete it!

		@mysql_query( "DELETE FROM reputationlevel WHERE reputationlevelid=$levelid" );
		rep_cache();

		redirect( 'reputation_ad.php?mode=done', 'Reputation deleted successfully', 5 );
	}


//////////////////////////////////////
//	Reputaion edit
//////////////////////////////////////

function show_form_rep()
	{
		global $input;
		
		if( ! isset($input['reputationid']) || ! is_valid_id($input['reputationid']) )
			stderr( '', 'Nothing here by that ID.' );
		
		$title = 'User Reputation Manager';

		$query = mysql_query( "SELECT r.*, p.topicid, t.subject, leftfor.username as leftfor_name, 
					leftby.username as leftby_name
					FROM reputation r
					left join posts p on p.id=r.postid
					left join topics t on p.topicid=t.id
					left join users leftfor on leftfor.id=r.userid
					left join users leftby on leftby.id=r.whoadded
					WHERE reputationid = ".intval($input['reputationid']) );
		

		if( ! $res = mysql_fetch_assoc( $query ) )
		{
			stderr( '', 'Erm, it\'s not there!' );
		}
		
		$html = "<form action='reputation_ad.php' name='show_rep_form' method='post'>
				<input name='reputationid' value='{$res['reputationid']}' type='hidden' />
				<input name='oldreputation' value='{$res['reputation']}' type='hidden' />
				<input name='mode' value='doeditrep' type='hidden' />";
		

		$html .= "<h2>Edit Reputation</h2>";
		$html .= "<table cellpadding='5px'>";

		$html .= "<tr><td width='37%'>Topic</td><td width='63%'><a href='forums.php?action=viewtopic&amp;topicid={$res['topicid']}&amp;page=p{$res['postid']}#{$res['postid']}' target='_blank'>".htmlsafechars($res['subject'])."</a></td></tr>";
		$html .= "<tr><td>Left By</td><td>{$res['leftby_name']}</td></tr>";
		$html .= "<tr><td>Left For</td><td width='63%'>{$res['leftfor_name']}</td></tr>";
		$html .= "<tr><td>Comment</td><td width='63%'><input type='text' name='reason' value='".htmlsafechars($res['reason'])."' size='35' maxlength='250' /></td></tr>";
		$html .= "<tr><td>Reputation</td><td><input type='text' name='reputation' value='{$res['reputation']}' size='35' maxlength='10' /></td></tr>";

		$html .= "<tr><td colspan='2' align='center'><input type='submit' value='Save' accesskey='s' class='btn' /> <input type='reset' tabindex='1' value='Reset' accesskey='r' class='btn' /></td></tr>";
		$html .= "</table></form>";

		html_out( $html, $title );
	}


/////////////////////////////////////
//	View reputation comments function
/////////////////////////////////////

function view_list()
	{
		global $now_date, $time_offset, $input;
		
		$title = 'User Reputation Manager';


        $html = '';

        $html .= "
                     <div class='cblock'>
                         <div class='cblock-header'>View Reputation Comments</div>
                         <div class='cblock-content'>";

		$html .= "           <p>This page allows you to search for reputation comments left by / for specific users over the specified date range.</p>";

		$html .= "           <form action='reputation_ad.php' id='list_form' method='post'>
		                          <input name='mode' value='list' type='hidden' />
				                  <input name='dolist' value='1' type='hidden' />";
		$html .= "                <table style='width:500px;' cellpadding='5'>";
		$html .= "                      <tr><td style='width:20%;'>Left For</td><td style='width:80%;'><input type='text' name='leftfor' value='' size='35' maxlength='250' tabindex='1' /></td></tr>";
		$html .= "                      <tr><td colspan='2'><div>To limit the comments left for a specific user, enter the username here. Leave this field empty to receive comments left for every user.</div></td></tr>";
		$html .= "                      <tr><td>Left By</td><td><input type='text' name='leftby' value='' size='35' maxlength='250' tabindex='2' /></td></tr>";
		$html .= "                      <tr><td colspan='2'><div>To limit the comments left by a specific user, enter the username here. Leave this field empty to receive comments left by every user.</div></td></tr>";
		$html .= "                      <tr>
                                           <td>Start Date</td>
                                           <td>
		                                      <div>
				                                  <span style='padding-right:5px; float:left;'>Month<br /><select name='start[month]' tabindex='3'>".get_month_dropdown(1)."</select></span>
				                                  <span style='padding-right:5px; float:left;'>Day<br /><input type='text' name='start[day]' value='".($now_date['mday']+1)."' size='4' maxlength='2' tabindex='3' /></span>
				                                  <span>Year<br /><input type='text' name='start[year]' value='".$now_date['year']."' size='4' maxlength='4' tabindex='3' /></span>
			                                 </div>
                                           </td>
                                        </tr>";
		$html .= "                      <tr><td class='tdrow2' colspan='2'><div class='desctext'>Select a start date for this report. Select a month, day, and year. The selected statistic must be no older than this date for it to be included in the report.</div></td></tr>";
		$html .= "                      <tr>
                                           <td>End Date</td>
                                           <td>
			                                  <div>
				                                  <span style='padding-right:5px; float:left;'>Month<br /><select name='end[month]' class='textinput' tabindex='4'>".get_month_dropdown()."</select></span>
				                                  <span style='padding-right:5px; float:left;'>Day<br /><input type='text' class='textinput' name='end[day]' value='".$now_date['mday']."' size='4' maxlength='2' tabindex='4' /></span>
				                                  <span>Year<br /><input type='text' class='textinput' name='end[year]' value='".$now_date['year']."' size='4' maxlength='4' tabindex='4' /></span>
			                                 </div>
                                           </td>
                                        </tr>";
		$html .= "                      <tr><td class='tdrow2' colspan='2'><div class='desctext'>Select an end date for this report. Select a month, day, and year. The selected statistic must not be newer than this date for it to be included in the report. You can use this setting in conjunction with the 'Start Date' setting to create a window of time for this report.</div></td></tr>";
		$html .= "                      <tr><td colspan='2' style='text-align:center;'><input type='submit' value='Search' accesskey='s' class='btn' tabindex='5' /> <input type='reset' value='Reset' accesskey='r' class='btn' tabindex='6' /></td></tr>";
		$html .= "                </table>
                             </form>";
//print $html; exit;

		// I hate work, but someone has to do it!
		if( isset($input['dolist']) )
		{
			$links = "";
			$input['orderby'] = isset($input['orderby']) ? $input['orderby'] : '';
			//$cond = ''; //experiment
			$who = isset($input['who']) ? (int)$input['who'] : 0;
			$user = isset($input['user']) ? $input['user'] : 0;
			$first = isset($input['page']) ? intval($input['page']) : 0;
			$cond =  $who ?"r.whoadded=".sqlesc($who) : '';

			$start = isset($input['startstamp']) ? intval($input['startstamp']) : mktime(0, 0, 0, $input['start']['month'], $input['start']['day'], $input['start']['year']) + $time_offset;

			$end   = isset($input['endstamp']) ? intval($input['endstamp']) : mktime(0, 0, 0, $input['end']['month'], $input['end']['day'] + 1, $input['end']['year']) + $time_offset;

			if( ! $start )
			{
				$start = TIME_NOW - (3600 * 24 * 30);
			}

			if( ! $end )
			{
				$end = TIME_NOW;
			}

			if( $start >= $end )
			{
				stderr( 'Time', 'Start date is after the end date.' );
			}

			if( ! empty($input['leftby']) )
			{
				$left_b = @mysql_query( "SELECT id FROM users WHERE username = ".sqlesc($input['leftby']) );

				if( ! mysql_num_rows($left_b) )
				{
					stderr( 'DB ERROR', 'Could not find user '.htmlsafechars($input['leftby']) );
				}
				$leftby = mysql_fetch_assoc($left_b);
				$who  = $leftby['id'];
				$cond = "r.whoadded=".$who;
			}

			if( ! empty($input['leftfor']) )
			{
				$left_f = @mysql_query( "SELECT id FROM users WHERE username = ".sqlesc($input['leftfor']) );

				if( ! mysql_num_rows($left_f) )
				{
					stderr( 'DB ERROR', 'Could not find user '.htmlsafechars($input['leftfor']) );
				}
				$leftfor = mysql_fetch_assoc($left_f);
				$user  = $leftfor['id'];
				$cond .= ($cond ? " AND" : "")." r.userid=".$user;
			}

			if( $start )
			{
				$cond .= ($cond ? " AND" : "")." r.dateadd >= $start";
			}

			if( $end )
			{
				$cond .= ($cond ? " AND" : "")." r.dateadd <= $end";
			}

			switch( $input['orderby'] )
			{
				case 'leftbyuser':
					$order = 'leftby.username';
					$orderby = 'leftbyuser';
					break;
				case 'leftforuser':
					$order = 'leftfor.username';
					$orderby = 'leftforuser';
					break;
				default:
					$order   = 'r.dateadd';
					$orderby = 'dateadd';
			}


			$css = "style='font-weight: bold;color: #ffffff;background-color: #0055A4;padding: 5px;'";
			$html = "<h2>Reputation Comments</h2>";
			$table_header = "<table style='width:80%;' cellpadding='5' border='1'><tr $css>";
			$table_header .= "<td style='width:2%;'>ID</td>";
			$table_header .= "<td style='width:20%;'><a href='reputation_ad.php?mode=list&amp;dolist=1&amp;who=".intval($who)."&amp;user=".intval($user)."&amp;orderby=leftbyuser&amp;startstamp=$start&amp;endstamp=$end&amp;page=$first'>Left By</a></td>";
			$table_header .= "<td style='width:20%;'><a href='reputation_ad.php?mode=list&amp;dolist=1&amp;who=".intval($who)."&amp;user=".intval($user)."&amp;orderby=leftforuser&amp;startstamp=$start&amp;endstamp=$end&amp;page=$first'>Left For</a></td>";
			$table_header .= "<td style='width:17%;'><a href='reputation_ad.php?mode=list&amp;dolist=1&amp;who=".intval($who)."&amp;user=".intval($user)."&amp;orderby=date&amp;startstamp=$start&amp;endstamp=$end&amp;page=$first'>Date</a></td>";
			$table_header .= "<td style='width:5%;'>Point</td>";
			$table_header .= "<td style='width:23%;'>Reason</td>";
			$table_header .= "<td style='width:10%;'>Controls</td></tr>";

			$html .= $table_header;

			// do the count for pager etc
			$query = mysql_query( "SELECT COUNT(*) AS cnt FROM reputation r WHERE $cond" );
			//print_r($input); exit;
			$total = mysql_fetch_assoc( $query );

			if( ! $total['cnt'] )
			{
				$html .= "<tr><td colspan='7' style='text-align:center;'>No Matches Found!</td></tr>";
			}

			// do the pager thang!
			$deflimit = 10;
			$links = "<span style=\"background: #F0F5FA; border: 1px solid #072A66;padding: 1px 3px 1px 3px;\">{$total['cnt']}&nbsp;Records</span>";
			if( $total['cnt'] > $deflimit ) 
			{
			
				require_once "include/pager.php";
				
				$links = pager( 
                  array( 
                  'count'  => $total['cnt'],
                  'perpage'    => $deflimit,
                  'start_value'  => $first,
                  'url'    => "reputation_ad.php?mode=list&amp;dolist=1&amp;who=".intval($who)."&amp;user=".intval($user)."&amp;orderby=$orderby&amp;startstamp=$start&amp;endstamp=$end"
                        )
                  );
			}
			
			// mofo query!
			$query = mysql_query( "SELECT r.*, p.topicid, leftfor.id as leftfor_id, 
									leftfor.username as leftfor_name, leftby.id as leftby_id, 
									leftby.username as leftby_name 
									FROM reputation r 
									left join posts p on p.id=r.postid 
									left join users leftfor on leftfor.id=r.userid 
									left join users leftby on leftby.id=r.whoadded 
									WHERE $cond ORDER BY $order LIMIT $first,$deflimit" );
			
			if( ! mysql_num_rows( $query ) ) stderr('DB ERROR', 'Nothing here');

			while( $r = mysql_fetch_assoc( $query ) )
			{
				$r['dateadd'] = date( "M j, Y, g:i a", $r['dateadd'] );

				$html .= "<tr><td>#{$r['reputationid']}</td>";
				$html .= "<td><a href='userdetails.php?id={$r['leftby_id']}' target='_blank'>{$r['leftby_name']}</a></td>";
				$html .= "<td><a href='userdetails.php?id={$r['leftfor_id']}' target='_blank'>{$r['leftfor_name']}</a></td>";
				$html .= "<td>{$r['dateadd']}</td>";
				$html .= "<td align='right'>{$r['reputation']}</td>";
				$html .= "<td><a href='forums.php?action=viewtopic&amp;topicid={$r['topicid']}&amp;page=p{$r['postid']}#{$r['postid']}' target='_blank'>{$r['reason']}</a></td>";
				$html .= "<td><a href='reputation_ad.php?mode=editrep&amp;reputationid={$r['reputationid']}'><span class='btn'>Edit</span></a>&nbsp;<a href='reputation_ad.php?mode=dodelrep&amp;reputationid=".htmlsafechars($r['reputationid'])."'><span class='btn'>Delete</span></a></td></tr>";
				
			}

			$html .= "</table>";
			$html .= "<br /><div>$links</div>";
		}

            $html .= "</div></div>";


		html_out( $html, $title);
	}

///////////////////////////////////////////////
//	Reputation do_delete_rep function
///////////////////////////////////////////////
function do_delete_rep()
	{
		global $input;
		
		if( ! is_valid_id($input['reputationid']) )
			stderr('ERROR', 'Can\'t find ID');
		// check it's a valid ID.
		$query = mysql_query( "SELECT reputationid, reputation, userid FROM reputation WHERE reputationid=".intval($input['reputationid'] ) );

		if( false === ( $r = mysql_fetch_assoc($query) ) )
		{
			stderr( 'DELETE', 'No valid ID.' );
		}

		// do the delete
		@mysql_query( "DELETE FROM reputation WHERE reputationid=".intval($r['reputationid'] ) );
		@mysql_query( "UPDATE users SET reputation = (reputation-{$r['reputation']} ) WHERE id=".intval($r['userid']) );

		redirect( "reputation_ad.php?mode=list", "Deleted Reputation Successfully", 5 );
	}


///////////////////////////////////////////////
//	Reputation do_edit_rep function
///////////////////////////////////////////////
function do_edit_rep()
	{
		global $input;
		
		if( isset($input['reason']) && ! empty($input['reason']) )
		{
			$reason = str_replace("<br />", "", $input['reason']);
			$reason = trim($reason);

			if( ( strlen(trim($reason)) < 2 ) || ( $reason == "" ) )
			{
				stderr( 'TEXT', 'The text you entered was too short.' );
			}

			if( strlen( $input['reason'] ) > 250 )
			{
				stderr( 'TEXT', 'The text entry is too long.' );
			}
		}

		$oldrep = intval($input['oldreputation']);
		$newrep = intval($input['reputation']);

		
		// valid ID?
		$query = mysql_query( "SELECT reputationid, reason, userid FROM reputation WHERE reputationid=".intval($input['reputationid'] ) );

		if( false === $r = mysql_fetch_assoc($query) )
		{
			stderr( 'INPUT', 'No ID' );
		}
/*
		if( $oldrep != $newrep )
		{
			if( $r['reason'] != $reason )
			{
				@mysql_query( "UPDATE reputation SET reputation = ".intval($newrep).", reason = ".sqlesc($reason).". WHERE reputationid = ".intval($r['reputationid']) );
			}

			$diff = $oldrep - $newrep;
			@mysql_query( "UPDATE users SET reputation = (reputation-{$diff}) WHERE id=".intval($r['userid']) );
		
		}
*/
    // untested
    if( $r['reason'] != $reason || $oldrep != $newrep)
        {
        @mysql_query( "UPDATE reputation SET reputation = ".intval($newrep).", reason = ".sqlesc($reason)." WHERE reputationid = ".intval($r['reputationid']) );
        }
        

         if( $oldrep != $newrep )
        {

        $diff = $oldrep - $newrep;
        @mysql_query( "UPDATE users SET reputation = (reputation-{$diff}) WHERE id=".intval($r['userid']) );
        
        } 
    
		redirect( "reputation_ad.php?mode=list", "Saved Reputation #ID{$r['reputationid']} Successfully.", 5);
	}

///////////////////////////////////////////////
//	Reputation output function
//	$msg -> string
//	$html -> string 
///////////////////////////////////////////////

function html_out( $html="", $title="" )
	{
		
		
		if( empty($html) )
		{
			stderr( "Error", "Nothing to output" );
		}

		
		print stdhead( $title ) . $html . stdfoot();
		
		exit();
		
	}
	
	

function redirect($url, $text, $time=2)
	{
		global $TBDEV;
		
		$page_title  = "Admin Rep Redirection";
		$page_detail = "<em>Redirecting...</em>";
		
		$html = "<meta http-equiv='refresh' content=\"{$time}; url={$TBDEV['baseurl']}/{$url}\">
						    <div>
							<div>Redirecting</div>
							<div style='padding:8px'>
							 <div style='font-size:12px'>$text
							 <br />
							 <br />
							 <center><a href='{$TBDEV['baseurl']}/{$url}'>Click here if not redirected...</a></center>
							 </div>
							</div>
						   </div>";
		
		print $html;
		exit;
	}


/////////////////////////////
//	get_month worker function
/////////////////////////////
function get_month_dropdown($i=0)
	{
        global $now_date;
        $return = '';
        $month = array('----','January','February','March','April','May','June','July','August','September','October','November','December');
		foreach( $month as $k => $m )
		{
			$return .= "\t<option value='".$k."'";
			$return .= ( ( $k + $i ) == $now_date['mon'] ) ? " selected='selected'" : "";
			$return .= ">".$m."</option>\n";
		}

		return $return;
	}	


/////////////////////////////
//	cache rep function
/////////////////////////////
function rep_cache()
	{
		
		$query = @mysql_query( "SELECT * FROM reputationlevel" );
		
		if( ! mysql_num_rows($query) )
			stderr( 'CACHE', 'No items to cache' );
		
		$rep_cache_file = "cache/rep_cache.php";
		$rep_out = "<"."?php\n\n\$reputations = array(\n";
		
		while( $row = mysql_fetch_assoc($query) )
		{
			$rep_out .= "\t{$row['minimumreputation']} => '{$row['level']}',\n";
		}
		
		$rep_out .= "\n);\n\n?".">";
		clearstatcache( $rep_cache_file );
		
		if( is_file( $rep_cache_file ) && is_writable( $rep_cache_file ) )
		{
			$filenum = fopen ( $rep_cache_file, 'w' );
			ftruncate( $filenum, 0 );
			fwrite( $filenum, $rep_out );
			fclose( $filenum );
		}
		
	}
?>