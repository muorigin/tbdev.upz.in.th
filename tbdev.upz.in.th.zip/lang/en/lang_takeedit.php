<?php

$lang = array(

#takedit
'takedit_failed' => "Edit failed!",
'takedit_no_data' => "missing form data",
'takedit_not_owner' => "You're not the owner! How did that happen?",
'takedit_nfo_error' => "NFO is too big! Max 65,535 bytes.",
'takedit_log' => "Torrent %s (%s) was edited by %s"
);

?>