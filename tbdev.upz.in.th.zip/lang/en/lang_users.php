<?php

$lang = array(


#head
'head_users' => "Users",


#form
'form_search' => "Search:",
'form_btn' => "Okay",


#pager
'pager_first' => "First",
'pager_last' => "Last",


#users
'users_regd' => "Registered",
'users_la' => "Last access",
'users_class' => "Class",
'users_country' => "Country",


);

?>