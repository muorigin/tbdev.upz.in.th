<?php

$lang = array(

#Texts
'text_puke' => "Puke",
'text_nfofor' => "NFO for ",
'text_forbest' => "For best visual result, install the ",
'text_linedraw' => "MS Linedraw",
'text_font' => " font"
);

?>
