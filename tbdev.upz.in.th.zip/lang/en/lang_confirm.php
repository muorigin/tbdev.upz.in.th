<?php

$lang = array(

#Confirm
'confirm_user_error' => "USER ERROR",
'confirm_invalid_id' => "Sorry, you have an invalid id",
'confirm_invalid_key' => "Sorry, you have an invalid key",
'confirm_cannot_confirm' => "Sorry, Cannot confirm you",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",

);

?>