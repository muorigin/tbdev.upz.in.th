<?php

$lang = array (


#header

'filelist_header' 			=> 'Filelist', 

#table headers

'filelist_path' 			=> 'Path', 
'filelist_size' 			=> 'Size'

);
?>
