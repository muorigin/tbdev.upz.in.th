<?php

$lang = array(

#Misc
'rules_rules' => "Rules Admin",
'stderr_error' => "Error",

#Texts
'rules_cat_title' => "Rules categories",
'rules_edit' => "Edit",
'rules_delete' => "Delete",
'rules_btn_newcat' => "Add New Category",
'rules_btn_newrule' => "Add New Rule",


);

?>