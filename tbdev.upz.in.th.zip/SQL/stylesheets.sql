-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 05, 2008 at 01:06 PM
-- Server version: 5.0.33
-- PHP Version: 5.2.1
-- 
-- Database: `tb`
-- 

-- 
-- Dumping data for table `stylesheets`
-- 

INSERT INTO `stylesheets` VALUES (1, '1', '(default)');

