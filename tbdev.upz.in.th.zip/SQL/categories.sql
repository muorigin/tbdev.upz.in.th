SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


INSERT INTO categories (id, name, image, cat_desc) VALUES
(1, 'Appz/PC ISO', 'cat_apps.gif', 'No Description'),
(2, 'Games/PC ISO', 'cat_games.gif', 'No Description'),
(3, 'Movies/SVCD', 'cat_movies.gif', 'No Description'),
(4, 'Music', 'cat_music.gif', 'No Description'),
(5, 'Episodes', 'cat_episodes.gif', 'No Description'),
(6, 'XXX', 'cat_xxx.gif', 'No Description'),
(7, 'Games/GBA', 'cat_games.gif', 'No Description'),
(8, 'Games/PS2', 'cat_games.gif', 'No Description'),
(9, 'Anime', 'cat_anime.gif', 'No Description'),
(10, 'Movies/XviD', 'cat_movies.gif', 'No Description'),
(11, 'Movies/DVD-R', 'cat_movies.gif', 'No Description'),
(12, 'Games/PC Rips', 'cat_games.gif', 'No Description'),
(13, 'Appz/misc', 'cat_apps.gif', 'No Description');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
