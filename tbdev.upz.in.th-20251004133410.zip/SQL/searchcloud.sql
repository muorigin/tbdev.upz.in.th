-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 03, 2009 at 03:23 PM
-- Server version: 5.0.33
-- PHP Version: 5.2.1
-- 
-- Database: `mytbdev`
-- 

-- 
-- Dumping data for table `searchcloud`
-- 

INSERT INTO `searchcloud` VALUES (1, 'bob', 1);
INSERT INTO `searchcloud` VALUES (2, 'testing', 4);
INSERT INTO `searchcloud` VALUES (3, 'blackadder', 1);
INSERT INTO `searchcloud` VALUES (4, '24', 2);