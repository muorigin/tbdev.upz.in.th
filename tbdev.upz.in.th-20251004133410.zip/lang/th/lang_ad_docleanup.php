<?php

$lang = array(

#Misc
'stderr_error' => "ข้อผิดพลาด",
'stderr_cleanup' => "การล้างข้อมูล",

#Texts
'text_incorrect' => "การเข้าถึงไม่ถูกต้อง",
'text_cannot' => "คุณไม่สามารถเข้าถึงไฟล์นี้โดยตรงได้",
'text_denied' => "การอนุญาตถูกปฏิเสธ !",
'text_done' => " เสร็จสิ้นเรียบร้อยแล้ว"
);

?>
