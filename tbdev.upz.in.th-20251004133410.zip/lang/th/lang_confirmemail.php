<?php

$lang = array(

#Confirmmail
'confirmmail_user_error' => "ข้อผิดพลาดของผู้ใช้",
'confirmmail_idiot' => "ไอ้โง่ ไม่มีข้อมูล!",
'confirmmail_no_key' => "ไม่ได้ตั้งคีย์",
'confirmmail_no-id' => "ไม่ได้ตั้ง id",
'confirmmail_false_email' => "ไม่ใช่ที่อยู่อีเมลจริง!",
'confirmmail_not_complete' => "ไม่สามารถเสร็จสิ้น",


);

?>