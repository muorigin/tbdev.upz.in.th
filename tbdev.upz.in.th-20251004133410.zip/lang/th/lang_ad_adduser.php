<?php

$lang = array(

#Misc
'stdhead_adduser' => "เพิ่มผู้ใช้",
'stderr_error' => "ข้อผิดพลาด",
'btn_okay' => "ตกลง",

#Texts
'text_incorrect' => "การเข้าถึงไม่ถูกต้อง",
'text_cannot' => "คุณไม่สามารถเข้าถึงไฟล์นี้โดยตรงได้",
'text_denied' => "การเข้าถึงถูกปฏิเสธ",
'text_missing' => "ข้อมูลฟอร์มขาดหายไป",
'text_passwd' => "รหัสผ่านไม่ตรงกัน",
'text_email' => "อีเมลไม่ถูกต้อง",
'text_username' => "ไม่สามารถสร้างบัญชีได้ ชื่อผู้ใช้อาจถูกใช้ไปแล้ว",
'text_adduser' => "เพิ่มผู้ใช้",

#The table
'table_username' => "ชื่อผู้ใช้",
'table_password' => "รหัสผ่าน",
'table_repasswd' => "พิมพ์รหัสผ่านอีกครั้ง",
'table_email' => "อีเมล"
);

?>
