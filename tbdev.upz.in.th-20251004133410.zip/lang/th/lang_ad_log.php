<?php

$lang = array(

#Misc
'stdhead_log' => "บันทึกไซต์",
'stderr_error' => "ข้อผิดพลาด",

#Texts
'text_incorrect' => "การเข้าถึงไม่ถูกต้อง",
'text_cannot' => "คุณไม่สามารถเข้าถึงไฟล์นี้โดยตรงได้",
'text_sitelog' => "บันทึกไซต์",
'text_logempty' => "บันทึกว่างเปล่า",
'text_times' => "เวลาเป็น GMT",

#The table
'header_date' => "วันที่",
'header_time' => "เวลา",
'header_event' => "เหตุการณ์"
);

?>
