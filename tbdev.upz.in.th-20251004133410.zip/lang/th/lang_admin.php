<?php

$lang = array(

#Admin
'admin_user_error' => "ข้อผิดพลาดของผู้ใช้",
'admin_unexpected' => "คุณมาที่นี่โดยไม่คาดคิด!",

);

?>