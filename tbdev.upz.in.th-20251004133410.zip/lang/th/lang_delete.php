<?php

$lang = array(

#Delete
'delete_failed' => "ลบล้มเหลว!",
'delete_missing_data' => "ข้อมูลฟอร์มขาดหายไป",
'delete_not_exist' => "ทอร์เรนต์ไม่มีอยู่",
'delete_not_owner' => "คุณไม่ใช่เจ้าของ! เกิดอะไรขึ้น?",
'delete_invalid' => "เหตุผลไม่ถูกต้อง",
'delete_dead' => "ตาย: 0 seeders, 0 leechers = 0 peers รวม",
'delete_dupe' => "ซ้ำ",
'delete_nuked' => "ถูกนัค",
'delete_violated' => "กรุณาอธิบายกฎที่ถูกละเมิด",
'delete_reason' => "กรุณาป้อนเหตุผลในการลบทอร์เรนต์นี้",
'delete_rules' => " กฎที่ถูกทำลาย: ",
'delete_go_back' => "กลับไปที่ที่คุณมาจาก",
'delete_back_index' => "กลับไปที่ดัชนี",
'delete_deleted' => "ทอร์เรนต์ถูกลบ!",
'delete_torrent' => "ทอร์เรนต์ ",
'delete_deleted_by' => " ถูกลบโดย ",

);

?>