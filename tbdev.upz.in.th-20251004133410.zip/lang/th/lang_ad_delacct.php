<?php

$lang = array(

#Misc
'stdhead_delete' => "ลบบัญชี",
'stderr_error' => "ข้อผิดพลาด",
'stderr_success' => "สำเร็จ",
'btn_delete' => "ลบ",

#Texts
'text_incorrect' => "การเข้าถึงไม่ถูกต้อง",
'text_cannot' => "คุณไม่สามารถเข้าถึงไฟล์นี้โดยตรงได้",
'text_please' => "กรุณากรอกแบบฟอร์มให้ถูกต้อง",
'text_bad' => "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง กรุณาตรวจสอบว่าข้อมูลที่ป้อนทั้งหมดถูกต้อง",
'text_unable' => "ไม่สามารถลบบัญชีได้",
'text_succes' => "บัญชีถูกลบแล้ว",
'text_delete' => "ลบบัญชี",
'text_adduser' => "เพิ่มผู้ใช้",

#The table
'table_username' => "ชื่อผู้ใช้",
'table_password' => "รหัสผ่าน"
);

?>
