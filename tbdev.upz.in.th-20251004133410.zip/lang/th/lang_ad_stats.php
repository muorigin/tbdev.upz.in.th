<?php
$lang = array(
#errors 
'stats_error' => 'ขออภัย...',
'stats_error1' => 'ไม่มีผู้อัปโหลด',
'stats_error2' => 'ไม่มีหมวดหมู่ที่กำหนด!',

#titles
'stats_title1' => 'กิจกรรมผู้อัปโหลด',
'stats_title2' => 'กิจกรรมหมวดหมู่',
'stats_window_title' => 'สถิติ',

'stats_last' => 'อัปโหลดล่าสุด',
'stats_peers' => 'เพียร์',
'stats_torrent' => 'ทอร์เรนต์',
'stats_uploader' => 'ผู้อัปโหลด',
'stats_category' => 'หมวดหมู่'
);

?>