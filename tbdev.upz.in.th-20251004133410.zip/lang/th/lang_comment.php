<?php

$lang = array(

#Comment
'comment_error' => "ข้อผิดพลาด",
'comment_invalid_id' => "ID ไม่ถูกต้อง",
'comment_invalid_torrent' => "ไม่มีทอร์เรนต์ที่มี ID",
'comment_body' => "เนื้อหาความคิดเห็นไม่สามารถว่างได้!",
'comment_add' => "เพิ่มความคิดเห็นไปที่ ",
'comment_doit' => "ทำเลย!",
'comment_recent' => "ความคิดเห็นล่าสุด ในลำดับย้อนกลับ",
'comment_denied' => "การอนุญาตถูกปฏิเสธ",
'comment_edit' => "แก้ไขความคิดเห็นไปที่ ",
'comment_delete' => "ลบความคิดเห็น",
'comment_about_delete' => "คุณกำลังจะลบความคิดเห็น คลิก",
'comment_delete_sure' => "ถ้าคุณแน่ใจ",
'comment_original_contents' => "เนื้อหาต้นฉบับของความคิดเห็น ",
'comment_back' => "กลับ",
'comment_original' => "ความคิดเห็นต้นฉบับ",
'comment_unknown' => "การดำเนินการที่ไม่รู้จัก",
'comment_' => "",
'comment_' => "",

);

?>