<?php

$lang = array(

#Browse
'browse_error' => "ข้อผิดพลาด",
'browse_invalid_cat' => "ID หมวดหมู่ไม่ถูกต้อง",
'browse_search' => "ผลการค้นหาสำหรับ ",
'browse_show_all' => "แสดงทั้งหมด",
'browse_active' => "ใช้งาน",
'browse_inc_dead' => "รวมตาย",
'browse_dead' => "ตายเท่านั้น",
'browse_go' => "ไป!",
'browse_search' => "ผลการค้นหาสำหรับ ",
'browse_not_found' => "ไม่พบอะไร!",
'browse_tryagain' => "ลองอีกครั้งด้วยสตริงการค้นหาที่ปรับปรุง",
'browse_nothing' => "ไม่มีอะไรที่นี่!",
'browse_sorry' => "ขออภัยเพื่อน :",


);

?>