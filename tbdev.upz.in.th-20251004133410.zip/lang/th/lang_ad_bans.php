<?php

$lang = array(

#Misc
'stdhead_adduser' => "แบน",
'stderr_error' => "ข้อผิดพลาด",
'btn_add' => "เพิ่ม",
'btn_cache' => "แคช",

#Texts
'text_incorrect' => "การเข้าถึงไม่ถูกต้อง",
'text_cannot' => "คุณไม่สามารถเข้าถึงไฟล์นี้โดยตรงได้",
'text_banremoved' => "แบน %s ถูกลบโดย ",
'text_missing' => "ข้อมูลฟอร์มขาดหายไป",
'text_badip' => "ที่อยู่ IP ไม่ถูกต้อง",
'text_current' => "แบนปัจจุบัน",
'text_nothing' => "ไม่พบอะไร",
'text_remove' => "ลบ",
'text_addban' => "เพิ่มแบน",

#The table
'header_added' => "เพิ่มแล้ว",
'header_firstip' => "IP แรก",
'header_lastip' => "IP สุดท้าย",
'header_by' => "โดย",
'header_comment' => "ความคิดเห็น",
'header_remove' => "ลบ",
'table_firstip' => "IP แรก",
'table_lastip' => "IP สุดท้าย",
'table_comment' => "ความคิดเห็น",
);

?>
