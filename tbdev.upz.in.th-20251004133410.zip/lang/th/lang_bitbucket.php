<?php

$lang = array(

#Bitbucket
'bitbucket_failed' => "อัปโหลดล้มเหลว",
'bitbucket_not_received' => "ไม่ได้รับอะไร!",
'bitbucket_too_large' => "ขออภัย ไฟล์นั้นใหญ่เกินไปสำหรับ bit-bucket",
'bitbucket_bad_name' => "ชื่อไฟล์ไม่ถูกต้อง",
'bitbucket_no_name' => "ขออภัย ไฟล์ที่มีชื่อ ",
'bitbucket_exists' => " มีอยู่แล้วใน bit-bucket",
'bitbucket_not_recognized' => "ขออภัย ไฟล์ที่คุณอัปโหลดไม่ได้รับการยอมรับว่าเป็นไฟล์ภาพที่ถูกต้อง",
'bitbucket_error' => "ข้อผิดพลาด",
'bitbucket_invalid_extension' => "นามสกุลไฟล์ไม่ถูกต้อง: <b>GIF, JPG หรือ PNG เท่านั้น!</b>",
'bitbucket_need_extension' => "ชื่อไฟล์ต้องมีนามสกุล",
'bitbucket_internal_error2' => "ข้อผิดพลาดภายใน 2",
'bitbucket_success' => "สำเร็จ",
'bitbucket_url' => "ใช้ URL ต่อไปนี้เพื่อเข้าถึงไฟล์: ",
'bitbucket_upload_another' => "อัปโหลดไฟล์อื่น",
'bitbucket_bbupload' => "อัปโหลด Bit-bucket",
'bitbucket_maximum' => "ขนาดไฟล์สูงสุด: ",
'bitbucket_bytes' => " ไบต์",
'bitbucket_upload_file' => "อัปโหลดไฟล์",
'bitbucket_upload' => "อัปโหลด",
'bitbucket_disclaimer' => "<b>คำปฏิเสธ:</b> อย่าอัปโหลดภาพที่ไม่ได้รับอนุญาตหรือผิดกฎหมาย ภาพที่อัปโหลดควรถูกพิจารณาว่าเป็น \"โดเมนสาธารณะ\"; อย่าอัปโหลดภาพที่คุณไม่ต้องการให้คนแปลกหน้าเข้าถึง",

);

?>