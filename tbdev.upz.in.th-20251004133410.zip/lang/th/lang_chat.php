<?php

$lang = array(

#Chat
'chat_channel' => "ช่อง IRC ทางการคือ ",
'chat_on' => " บน ",
'chat_network' => "เครือข่าย",
'chat_chat' => "แชท",


);

?>