<?php

$lang = array(

#Confirm
'confirm_user_error' => "ข้อผิดพลาดของผู้ใช้",
'confirm_invalid_id' => "ขออภัย คุณมี id ที่ไม่ถูกต้อง",
'confirm_invalid_key' => "ขออภัย คุณมีคีย์ที่ไม่ถูกต้อง",
'confirm_cannot_confirm' => "ขออภัย ไม่สามารถยืนยันคุณได้",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",
'confirm_' => "",

);

?>