<?php
$lang = array(
'testip_error' =>'ข้อผิดพลาด',
'testip_error1' =>'IP ไม่ถูกต้อง',
'testip_result' =>'ผลลัพธ์',
'testip_notice' =>'ที่อยู่ IP <b>%s</b> ไม่ถูกแบน',
'testip_notice1' =>'ที่อยู่ IP <b>%s</b> ถูกแบน',
'testip_first' =>'แรก',
'testip_last' =>'สุดท้าย',
'testip_comment' =>'ความคิดเห็น',
'testip_address' =>'ที่อยู่ IP',
'testip_ok' =>'ตกลง',
'testip_title' =>'ทดสอบที่อยู่ IP',
'testip_windows_title' =>'ทดสอบ IP',

);
?>