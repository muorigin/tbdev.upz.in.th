<?php
$lang = array(
#errors 
'stats_error' => 'Sorry...',
'stats_error1' => 'No uploaders.',
'stats_error2' => 'No categories defined!',

#titles
'stats_title1' => 'Uploader Activity',
'stats_title2' => 'Category Activity',
'stats_window_title' => 'Stats',

'stats_last' => 'Last upload',
'stats_peers' => 'Peers',
'stats_torrent' => 'Torrents',
'stats_uploader' => 'Uploader',
'stats_category' => 'Category'
);

?>