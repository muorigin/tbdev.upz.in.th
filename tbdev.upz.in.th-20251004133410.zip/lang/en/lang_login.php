<?php

$lang = array(

#Login
'login_spam' => "NO SPAM! Wait 10 seconds and then refresh page",
'login_not_logged_in' => "Not logged in!",
'login_error' => "The page you tried to view can only be used when you're logged in.\n",
'login_username' => "Username:",
'login_password' => "Password:",
'login_duration' => "Duration:",
'login_15mins' => "Log me out after 15 minutes inactivity",
'login_refresh' => "Click to refresh image",
'login_captcha' => "Captcha image",
'login_pin' => "PIN:",
'login_login' => "Log in!",
'login_signup' => "<p>Don't have an account? <a href='members.php?action=reg'>Sign up</a> right now!</p>",
'login_login_btn' => "Login",



);

?>