<?php

$lang = array(

#SEARCH
'search_search' => "Search",
'search_in' => "in",
'search_all_types' => "(all types)",
'search_inc_dead' => "including dead torrents\n",
'search_search_btn' => "Search!"

);

?>