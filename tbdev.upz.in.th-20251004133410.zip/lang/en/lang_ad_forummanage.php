<?php

$lang = array(

#Misc
'btn_addnew' => "Add New",
'btn_cancel' => "Cancel",
'btn_makeforum' => "Make Forum",
'btn_editforum' => "Edit Forum",
'btn_moveto' => "Move To...",
'stdhead_forummanagetools' => "Forum Management Tools",
'stdhead_addforum' => "Add Forum",
'stdhead_editforum' => "Edit Forum",
'stderr_success' => "Success",
'stderr_error' => "Error",
'stdearr_warning' => "Warning",

#Texts
'text_permission' => "Permission denied.",
'text_minimal' => "minimal",
'text_edit' => "Edit",
'text_delete' => "Delete",
'text_sorry' => "Sorry, no records were found!",
'text_added' => "Forum Added",
'text_edited' => "Forum Edited",
'text_error' => "There was an error",
'text_return' => "Return to Forum Management",
'text_noid' => "No fecking id !",
'text_notopic' => "There are no topics in this forum !",
'text_smthbad' => "Something bad happened!",
'text_forumdeleted' => "Forum deleted, return to",
'text_deleted_text' => "Forum Management",
'text_nowheretomove' => "Nowhere to move to!",
'text_warning' => "You are about to delete a forum! ",
'text_warning_cont' => " Continue? ",
'text_select' => "Select Forum to move topics to: ",

#The table
'header_name' => "Name",
'header_topics' => "Topics",
'header_posts' => "Posts",
'header_read' => "Read",
'header_write' => "Write",
'header_createtopic' => "Create Topic",
'header_modify' => "Modify",
'header_makenew' => "Make New Forum",
'header_editforum' => "Edit Forum:",
'frame_editforum' => "Edit Forum",
'table_forumname' => "Forum Name",
'table_forumdescr' => "Forum Description",
'table_minreadperm' => "Minimum Read Permission",
'table_minwriteperm' => "Minimum Write Permission",
'table_mincreatetperm' => "Minimun Create Topic Permission",
'table_minpostrank' => "Minimal Post Rank",
'table_mincreatetrank' => "Minimal Create Topic Rank",
'table_forumrank' => "Forum Rank"
);

?>
