<?php

$lang = array(

#Logout
'logout_' => "",


);

?>