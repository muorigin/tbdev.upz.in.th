<?php
$lang = array(
'testip_error' =>'Error',
'testip_error1' =>'Bad ip',
'testip_result' =>'Result',
'testip_notice' =>'The IP address <b>%s</b> is not banned.',
'testip_notice1' =>'The IP address <b>%s</b> is banned.',
'testip_first' =>'First',
'testip_last' =>'Last',
'testip_comment' =>'Comment',
'testip_address' =>'Ip address',
'testip_ok' =>'Ok',
'testip_title' =>'Test IP address',
'testip_windows_title' =>'Test ip',

);
?>