<?php

$bans = array(
array('id'=> '7', 'first'=> 1545076736, 'last'=> 1545469951),
array('id'=> '6', 'first'=> 1358861092, 'last'=> 1358861092),
array('id'=> '5', 'first'=> 1509007919, 'last'=> 1509007919),
array('id'=> '4', 'first'=> -1017309914, 'last'=> -1017309914),
array('id'=> '3', 'first'=> 407781447, 'last'=> 407840124),

);

?>